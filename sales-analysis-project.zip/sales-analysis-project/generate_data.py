"""
Step 1: Create a sample sales dataset.

Run this file once. It creates data/sales_data.csv
(You can replace this CSV with your own real data later.)
"""

import os

import numpy as np
import pandas as pd

os.makedirs("data", exist_ok=True)

np.random.seed(42)  # same random numbers every time

n = 1000  # number of sales records

products = {
    "Laptop": 55000,
    "Smartphone": 20000,
    "Headphones": 2500,
    "Smartwatch": 8000,
    "Tablet": 25000,
}
regions = ["North", "South", "East", "West"]

dates = pd.date_range("2025-01-01", "2025-12-31")

df = pd.DataFrame({
    "Order_ID": range(1001, 1001 + n),
    "Date": np.random.choice(dates, n),
    "Region": np.random.choice(regions, n),
    "Product": np.random.choice(list(products.keys()), n),
    "Quantity": np.random.randint(1, 6, n),
})

df["Unit_Price"] = df["Product"].map(products)
df["Revenue"] = df["Quantity"] * df["Unit_Price"]
df = df.sort_values("Date")

df.to_csv("data/sales_data.csv", index=False)
print("Done! data/sales_data.csv created with", len(df), "rows.")
