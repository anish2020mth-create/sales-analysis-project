# Sales Data Analysis using Python

**Author:** Anish Raj
**Course:** PGDM (Business Analytics), NIET Business School, Greater Noida
**Tools:** Python, Pandas, Matplotlib

## About the Project
This is a simple business analytics project. It analyses one year (2025) of sales data of an electronics company and answers basic business questions:

- How much total revenue did the company earn?
- Which product earns the most?
- Which region sells the most?
- Which month was the best?

## Project Structure
```
sales-analysis-project/
├── data/
│   └── sales_data.csv        # sales dataset (1000 orders)
├── images/                   # charts created by the code
├── generate_data.py          # creates the sample dataset
├── sales_analysis.py         # main analysis code
├── summary.txt               # final summary of results
├── requirements.txt          # libraries needed
└── README.md
```

## How to Run
1. Install Python (3.8 or newer) and open a terminal in this folder.
2. Install the libraries:
   ```
   pip install -r requirements.txt
   ```
3. (Optional) Create a fresh dataset:
   ```
   python generate_data.py
   ```
4. Run the analysis:
   ```
   python sales_analysis.py
   ```

## Dataset Columns
| Column | Meaning |
|---|---|
| Order_ID | Unique order number |
| Date | Date of sale |
| Region | North / South / East / West |
| Product | Laptop, Smartphone, Headphones, Smartwatch, Tablet |
| Quantity | Units sold |
| Unit_Price | Price of one unit (Rs) |
| Revenue | Quantity x Unit_Price |

> The data is sample (computer generated) data made for learning. You can replace `data/sales_data.csv` with real data that has the same columns.

## Results
- **Total Revenue:** Rs 6.74 crore (Rs 67,436,500)
- **Total Orders:** 1000
- **Average Order Value:** Rs 67,436
- **Top Product:** Laptop (about 49% of revenue)
- **Top Region:** North
- **Best Month:** August

### Charts
![Revenue by Product](images/revenue_by_product.png)
![Revenue by Region](images/revenue_by_region.png)
![Monthly Trend](images/monthly_trend.png)

## Key Insights
- Laptops bring in almost half of the total revenue, even though they are only one of five products.
- Headphones sell often but add very little revenue because of the low price.
- North is the strongest region, so it deserves the most marketing focus.

## What I Learned
- Loading and cleaning data with Pandas
- Grouping data to answer business questions (`groupby`)
- Making charts with Matplotlib

## Contact
Anish Raj | anish2020.mth@gmail.com | [LinkedIn](https://www.linkedin.com/in/anish-raj-579357276)
